extends CharacterBody2D


const SPEED = 600.0
const JUMP_VELOCITY = -900.0
var coins=0
var max_coins=10
var switch = false
signal all_coins
func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta*2
	if  is_on_floor():
		$AnimatedSprite2D.animation="walk"
	# Handle jump.
	if Input.is_action_just_pressed("up") and $AnimatedSprite2D.animation=="walk":
		velocity.y = JUMP_VELOCITY
		$AnimatedSprite2D.animation="jump"
		
	if Input.is_action_just_pressed("respawn"):
		position = Vector2(0,0)

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("left", "right")
	if direction:
		velocity.x = direction * SPEED
		if is_on_floor():
			velocity.y-=200
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
	move_and_slide()


func _on_coin_get_coin():
	coins+=1
	if coins==max_coins:
		emit_signal("all_coins")


func _on_switch_flip() -> void:
	hide()
